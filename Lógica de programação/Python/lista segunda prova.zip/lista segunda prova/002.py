for i in range(300, 100, 3):
    print(i)
