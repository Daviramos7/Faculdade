for i in range(100, 200, -3):
    print(i)
