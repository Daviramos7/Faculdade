nome_aluno = input("Digite o nome do aluno: ")
nota_aluno = float(input("Digite a nota do aluno: "))

if nota_aluno >= 7:
    print(nome_aluno, "Aprovado, Parabéns")
else:
    print(nome_aluno, "Reprovado, Melhore!")